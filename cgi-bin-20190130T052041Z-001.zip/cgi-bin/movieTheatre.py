#CST 363
import cgitb , cgi
import mysql.connector

cgitb.enable()
form = cgi.FieldStorage()

#
# retrieve input values
movie_ID = form["select_showtime"].value

#  code to do SQL goes here
qsql = 'select * from movie where movieID = %s'

# connect to database
cnx = mysql.connector.connect(user='root',
                            password='CST363pw$',
                            database='movietheater',
                            host='127.0.0.1')
cursor = cnx.cursor()
cursor.execute(qsql, (movie_ID,))
row = cursor.fetchone()

movie_name = row[1]
 
print("Content-Type: text/html")    # HTML is following
print()                             # blank line required, end of headers
print("<html><body>")
print("<p>You have booked to see ", movie_name, "</p><br>")


print("</body></html>")
cnx.close()  # close the connection 
